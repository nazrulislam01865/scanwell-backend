import hashlib
import hmac
import secrets


class VerificationCodeService:
    def __init__(self, secret_key: str) -> None:
        self._secret = secret_key.encode("utf-8")

    def generate(self) -> str:
        return f"{secrets.randbelow(1_000_000):06d}"

    def digest(self, code: str) -> str:
        return hmac.new(self._secret, code.encode("utf-8"), hashlib.sha256).hexdigest()

    def matches(self, code: str, digest: str) -> bool:
        return hmac.compare_digest(self.digest(code), digest)
