import asyncio
import logging
import smtplib
from email.message import EmailMessage

from app.modules.auth.domain.value_objects import VerificationPurpose

logger = logging.getLogger(__name__)


class LoggingEmailService:
    async def send_verification_code(
        self,
        *,
        email: str,
        code: str,
        purpose: VerificationPurpose,
    ) -> None:
        logger.info("ScanWell verification code for %s (%s): %s", email, purpose.value, code)


class SMTPEmailService:
    def __init__(
        self,
        *,
        host: str,
        port: int,
        username: str | None,
        password: str | None,
        from_address: str,
        use_tls: bool,
    ) -> None:
        self._host = host
        self._port = port
        self._username = username
        self._password = password
        self._from_address = from_address
        self._use_tls = use_tls

    async def send_verification_code(
        self,
        *,
        email: str,
        code: str,
        purpose: VerificationPurpose,
    ) -> None:
        await asyncio.to_thread(self._send, email, code, purpose)

    def _send(self, email: str, code: str, purpose: VerificationPurpose) -> None:
        subject = (
            "Verify your ScanWell email"
            if purpose is VerificationPurpose.EMAIL_VERIFICATION
            else "Your ScanWell login code"
        )
        message = EmailMessage()
        message["Subject"] = subject
        message["From"] = self._from_address
        message["To"] = email
        message.set_content(
            f"Your ScanWell verification code is {code}. "
            "This code expires shortly. If you did not request it, ignore this email."
        )

        with smtplib.SMTP(self._host, self._port, timeout=15) as smtp:
            if self._use_tls:
                smtp.starttls()
            if self._username:
                smtp.login(self._username, self._password or "")
            smtp.send_message(message)
